/**
 * @file  main.c
 * @brief 主程序入口
 * @details 包含主函数和系统初始化
 * @author konbakuyomu
 * @date 2025-03-05
 */

#include "globalConfig.h"

/**
 * @brief 系统初始化
 * @param 无
 * @retval 无
 * @note
 * hc32f460_system_init()函数用于初始化系统时钟、外部时钟源、CPU使用率统计和串口printf
 */
static void hc32f460SystemInit(void)
{
    /* 将系统时钟配置为200MHz */
    BSP_CLK_Init();
    /* 外部时钟源32kb初始化(未使用) */
    // BSP_XTAL32_Init();
    /* CPU使用率统计初始化 */
//    configCpuTmr0();
    /* 开启CPU使用率统计 */
//    startUtilization();
    /* 初始化LED */
    BSP_LED_Init();
}

/**
 * @brief LED任务函数
 * @param pvParameters 任务参数
 * @retval 无
 */
static void vLedTask(void* pvParameters)
{
    for (;;) {
        /* 切换LED状态 */
        BSP_LED_Toggle(LED_YELLOW);
        /* 延时1000ms */
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/**
 * @brief  主函数
 * @details 初始化系统，创建任务，启动调度器
 * @retval int
 * @note   正常情况下不会返回，会一直运行在FreeRTOS调度器中
 */
int main(void)
{
    /* 对指定的外设寄存器解锁（解锁后才能写入） */
    LL_PERIPH_WE(LL_PERIPH_ALL);
    /* 系统初始化 */
    hc32f460SystemInit();

    /* 创建LED任务 */
    xTaskCreate(vLedTask,                 /* 任务函数 */
                "LED Task",               /* 任务名称 */
                configMINIMAL_STACK_SIZE, /* 任务堆栈大小 */
                NULL,                     /* 任务参数 */
                3,                        /* 任务优先级 */
                NULL);                    /* 任务句柄 */

    /* 启动调度器 */
    vTaskStartScheduler();

    /* 正常不会执行到这里 */
    for (;;) { }
}
